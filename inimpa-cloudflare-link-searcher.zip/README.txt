Inimpa Link Searcher — Cloudflare Pages

Dateien:
- index.html
- functions/api/check.js

Bereitstellung:
1. Entpacke dieses ZIP.
2. Lade beide Dateien in ein GitHub-Repository hoch oder verbinde ein Repository mit Cloudflare Pages.
3. In Cloudflare: Workers & Pages → Create → Pages → Connect to Git.
4. Wähle das Repository. Bei einer reinen HTML-Seite kann das Build command leer bleiben; Output directory auf das Projektverzeichnis setzen (oft `.`).
5. Nach dem Deploy die Website öffnen und zuerst einen kleinen Versionsbereich testen, z. B. 3_5 bis 3_0.

Wichtig:
- Die Function-Route `/api/check` ist in `functions/api/check.js` definiert.
- Der Scanner ist auf höchstens 300 Versionen pro Durchlauf begrenzt.
- HTTP-Erreichbarkeit ist kein Beweis für offizielle Zugehörigkeit zu Inimpa; manche Plattformen liefern auch für nicht vorhandene Seiten eigene Fehlerseiten aus.
- Die URL-Namen werden aus dem vom Nutzer angegebenen Versionsmuster konstruiert. Nur eigene oder zur Prüfung autorisierte Domains prüfen.
