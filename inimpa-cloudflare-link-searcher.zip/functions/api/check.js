export async function onRequestGet({ request }) {
  const url = new URL(request.url);
  const version = url.searchParams.get("version") || "";
  const match = /^(3|[4-9]|[1-9]\d|100)_(\d{1,3})$/.exec(version);

  if (!match || Number(match[2]) > 999) {
    return Response.json({ error: "Ungültige Version", exists: false }, { status: 400 });
  }

  const target = `https://inimpa${Number(match[1])}_${Number(match[2])}.oneapp.dev/`;

  try {
    const response = await fetch(target, {
      method: "GET",
      redirect: "follow",
      signal: AbortSignal.timeout(7000)
    });
    const exists = response.status >= 200 && response.status < 400 &&
                   response.status !== 204;
    return Response.json(
      { version, exists, status: response.status, url: target },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch {
    return Response.json(
      { version, exists: false, error: "Nicht erreichbar oder Zeitüberschreitung" },
      { headers: { "Cache-Control": "no-store" } }
    );
  }
}
